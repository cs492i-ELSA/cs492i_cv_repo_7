from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import os
import argparse

import numpy as np
import shutil
import random
import time

import torch
import torch.nn as nn
import torch.optim as optim
from torch.optim import lr_scheduler
from torch.autograd import Variable
import torch.backends.cudnn as cudnn
import torch.nn.functional as F
from torchvision.models import *
from torchvision import datasets, models, transforms
import torch.nn.functional as F

from ImageDataLoader import SimpleImageLoader
from models import Res18, Res50, Dense121 , Res18_basic
from residual_attention_network import ResidualAttentionModel_92
import glob
from model_resnet import ResidualNet
from attention_module import AttentionModule_stage1
import os
from bam import BAM
import argparse


import nsml
from nsml import DATASET_PATH, IS_ON_NSML

### LP-DeepSSL ###
import re
import argparse
import os
import shutil
import time
import math

import pdb

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.backends.cudnn as cudnn
from torch.autograd import Variable
from torch.utils.data import DataLoader
from torch.utils.data.sampler import BatchSampler, SubsetRandomSampler
import torchvision.datasets
from helpers import *
###

# import tqdm
# from tqdm import tqdm_notebook as tqdm
NUM_CLASSES = 265
if not IS_ON_NSML:
    DATASET_PATH = '../../NSML/datasets/fashion_dataset'

def top_n_accuracy_score(y_true, y_prob, n=5, normalize=True):
    num_obs, num_labels = y_prob.shape
    idx = num_labels - n - 1
    counter = 0
    argsorted = np.argsort(y_prob, axis=1)
    for i in range(num_obs):
        if y_true[i] in argsorted[i, idx+1:]:
            counter += 1
    if normalize:
        return counter * 1.0 / num_obs
    else:
        return counter
        
class AverageMeter(object):
    """Computes and stores the average and current value"""
    def __init__(self):
        self.reset()
    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0
    def update(self, val, n=1):
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count
        
def adjust_learning_rate(opts, optimizer, epoch):
    """Sets the learning rate to the initial LR decayed by 10 every 30 epochs"""
    lr = opts.lr * (0.1 ** (epoch // 30))
    for param_group in optimizer.param_groups:
        param_group['lr'] = lr
        
def linear_rampup(current, rampup_length):
    if rampup_length == 0:
        return 1.0
    else:
        current = np.clip(current / rampup_length, 0.0, 1.0)
        return float(current)
        
class SemiLoss(object):
    def __call__(self, outputs_x, targets_x, outputs_u, targets_u, epoch, final_epoch):
        probs_u = torch.softmax(outputs_u, dim=1)
        Lx = -torch.mean(torch.sum(F.log_softmax(outputs_x, dim=1) * targets_x, dim=1))
        Lu = torch.mean((probs_u - targets_u)**2)
        return Lx, Lu, opts.lambda_u * linear_rampup(epoch, final_epoch)

def pair_cosine_similarity(x, eps=1e-8):
    n = x.norm(p=2, dim=1, keepdim=True)
    return (x @ x.t()) / (n * n.t()).clamp(min=eps)

def nt_xent(x, t=0.5):
    x = pair_cosine_similarity(x)
    x = torch.exp(x / t)
    idx = torch.arange(x.size()[0])
    idx[::2] += 1
    idx[1::2] -= 1
    x = x[idx]
    x = x.diag() / (x.sum(0) - torch.exp(torch.tensor(1 / t)))
    return -torch.log(x.mean())

def interleave_offsets(batch, nu):
    groups = [batch // (nu + 1)] * (nu + 1)
    for x in range(batch - sum(groups)):    
        groups[-x - 1] += 1
    offsets = [0]
    for g in groups:
        offsets.append(offsets[-1] + g)
    assert offsets[-1] == batch
    return offsets

def interleave(xy, batch):
    nu = len(xy) - 1
    offsets = interleave_offsets(batch, nu)
    xy = [[v[offsets[p]:offsets[p + 1]] for p in range(nu + 1)] for v in xy]
    for i in range(1, nu + 1):
        xy[0][i], xy[i][i] = xy[i][i], xy[0][i]
    return [torch.cat(v, dim=0) for v in xy]


def split_ids(path, ratio):
    with open(path) as f:
        ids_l = []
        ids_u = []
        for i, line in enumerate(f.readlines()):
            if i == 0 or line == '' or line == '\n':
                continue
            line = line.replace('\n', '').split('\t')
            if int(line[1]) >= 0:
                ids_l.append(int(line[0]))
            else:
                ids_u.append(int(line[0]))

    ids_l = np.array(ids_l)
    ids_u = np.array(ids_u)

    perm = np.random.permutation(np.arange(len(ids_l)))
    cut = int(ratio*len(ids_l))
    train_ids = ids_l[perm][cut:]
    val_ids = ids_l[perm][:cut]

    return train_ids, val_ids, ids_u


### NSML functions
def _infer(model, root_path, test_loader=None):
    if test_loader is None:
        test_loader = torch.utils.data.DataLoader(
            SimpleImageLoader(root_path, 'test',
                               transform=transforms.Compose([
                                   transforms.Resize(opts.imResize),
                                   transforms.CenterCrop(opts.imsize),
                                   transforms.ToTensor(),
                                   transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
                               ])), batch_size=opts.batchsize, shuffle=False, num_workers=4, pin_memory=True)
        print('loaded {} test images'.format(len(test_loader.dataset)))

    outputs = []
    s_t = time.time()
    for idx, image in enumerate(test_loader):
        if torch.cuda.is_available():
            image = image.cuda()
        probs = model(image)
        output = torch.argmax(probs, dim=1)
        output = output.detach().cpu().numpy()
        outputs.append(output)

    outputs = np.concatenate(outputs)
    return outputs

def bind_nsml(model):
    def save(dir_name, *args, **kwargs):
        os.makedirs(dir_name, exist_ok=True)
        state = model.module.state_dict()
        torch.save(state, os.path.join(dir_name, 'model.pt'))
        print('saved')

    def load(dir_name, *args, **kwargs):
        state = torch.load(os.path.join(dir_name, 'model.pt'))
        model.load_state_dict(state)
        print('loaded')

    def infer(root_path):
        return _infer(model, root_path)

    nsml.bind(save=save, load=load, infer=infer)


######################################################################
# Options
######################################################################
parser = argparse.ArgumentParser(description='Sample Product200K Training')
parser.add_argument('--start_epoch', type=int, default=1, metavar='N', help='number of start epoch (default: 1)')
parser.add_argument('--epochs', type=int, default=200, metavar='N', help='number of epochs to train (default: 200)')
parser.add_argument('--start_epoch_pretask', type=int, default=1, metavar='N', help='number of start epoch (default: 1)')
# basic settings
parser.add_argument('--name',default='Res18baseMM', type=str, help='output model name')
parser.add_argument('--gpu_ids',default='0', type=str,help='gpu_ids: e.g. 0  0,1,2  0,2')
parser.add_argument('--batchsize', default=64, type=int, help='batchsize')
# parser.add_argument('--batchsize', default=200, type=int, help='batchsize')
parser.add_argument('--seed', type=int, default=123, help='random seed')

# basic hyper-parameters
parser.add_argument('--momentum', type=float, default=0.9, metavar='LR', help=' ')
parser.add_argument('--lr', type=float, default=1e-3, metavar='LR', help='learning rate (default: 5e-5)')
parser.add_argument('--imResize', default=256, type=int, help='')
parser.add_argument('--imsize', default=224, type=int, help='')
parser.add_argument('--lossXent', type=float, default=1, help='lossWeight for Xent')

# arguments for logging and backup
parser.add_argument('--log_interval', type=int, default=10, metavar='N', help='logging training status')
parser.add_argument('--save_epoch', type=int, default=50, help='saving epoch interval')

# hyper-parameters for mix-match
parser.add_argument('--alpha', default=0.75, type=float)
parser.add_argument('--lambda-u', default=75, type=float)
parser.add_argument('--T', default=0.5, type=float)

### DO NOT MODIFY THIS BLOCK ###
# arguments for nsml 
parser.add_argument('--pause', type=int, default=0)
parser.add_argument('--mode', type=str, default='train')
################################

def main():
    global opts
    opts = parser.parse_args()
    opts.cuda = 0

    # Set GPU
    seed = opts.seed
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    os.environ['CUDA_VISIBLE_DEVICES'] = opts.gpu_ids
    use_gpu = torch.cuda.is_available()
    if use_gpu:
        opts.cuda = 1
        print("Number of device: {}".format(torch.cuda.device_count()))
        print("Currently using GPU {}".format(opts.gpu_ids))
        cudnn.benchmark = True
        torch.cuda.manual_seed_all(seed)
    else:
        print("Currently using CPU (GPU is highly recommended)")


    # Set model
    # model = Res18_basic(NUM_CLASSES)
    model = ResidualAttentionModel_92()
    # model.conv1 = nn.Conv2d(3, 3, 1, 1, bias=False)
    # model.maxpool = nn.Identity()

    ch = model.fc.in_features
    model.fc = nn.Linear(ch, NUM_CLASSES)  
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    # model = torch.nn.DataParallel(model)
    model.eval()

    parameters = filter(lambda p: p.requires_grad, model.parameters())
    n_parameters = sum([p.data.nelement() for p in model.parameters()])
    print('  + Number of params: {}'.format(n_parameters))


    ### GPU Setup ###
    if use_gpu:
        model.cuda()
    ### DO NOT MODIFY THIS BLOCK ###
    if IS_ON_NSML:
        bind_nsml(model)
        if opts.pause:
            nsml.paused(scope=locals())
    ################################
    if opts.mode == 'train':
        # model.fc = nn.Sequential(nn.Linear(ch, ch), nn.ReLU(), nn.Linear(ch, ch))

        # Set dataloader
        train_ids, val_ids, unl_ids = split_ids(os.path.join(DATASET_PATH, 'train/train_label'), 0.2)
        print('found {} train, {} validation and {} unlabeled images'.format(len(train_ids), len(val_ids), len(unl_ids)))
        label_loader = torch.utils.data.DataLoader(
            SimpleImageLoader(DATASET_PATH, 'train', train_ids,
                              transform=transforms.Compose([
                                  transforms.Resize(opts.imResize),
                                  transforms.RandomResizedCrop(opts.imsize),
                                  # transforms.Resize((opts.imsize, opts.imsize)),
                                  transforms.RandomHorizontalFlip(),
                                  # transforms.ColorJitter(0.5, 0.5, 0.5, 0.5),
                                  transforms.ToTensor(),
                                  transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),])),
                                batch_size=opts.batchsize * 2, shuffle=True, num_workers=4, pin_memory=True, drop_last=True)
        print('train_loader done')

        unlabel_loader = torch.utils.data.DataLoader(
            SimpleImageLoader(DATASET_PATH, 'unlabel', unl_ids,
                              transform=transforms.Compose([
                                  transforms.Resize(opts.imResize),
                                  transforms.RandomResizedCrop(opts.imsize),
                                  transforms.ColorJitter(0.5, 0.5, 0.5, 0.5),
                                  transforms.ToTensor(),
                                  transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),])),
                                batch_size=opts.batchsize, shuffle=True, num_workers=4, pin_memory=True, drop_last=True)
        print('unlabel_loader done')

        unlabel_unsym_loader = torch.utils.data.DataLoader(
            SimpleImageLoader(DATASET_PATH, 'unlabel', unl_ids, unsym=True,
                              transform=transforms.Compose([
                                  transforms.Resize(opts.imResize),
                                  transforms.RandomResizedCrop(opts.imsize),
                                  transforms.ColorJitter(0.5, 0.5, 0.5, 0.5),
                                  transforms.ToTensor(),
                                  transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),]),
                              transform_base=transforms.Compose([
                                  transforms.Resize((opts.imsize, opts.imsize)),
                                  #transforms.RandomResizedCrop(opts.imsize),
                                  # transforms.Resize((opts.imsize, opts.imsize)),
                                  transforms.RandomHorizontalFlip(),
                                  # transforms.ColorJitter(0.5, 0.5, 0.5, 0.5),
                                  transforms.ToTensor(),
                                  transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),])),
                                batch_size=opts.batchsize * 2, shuffle=True, num_workers=4, pin_memory=True, drop_last=True)
        print('unlabel_unsym_loader done')  


        validation_loader = torch.utils.data.DataLoader(
            SimpleImageLoader(DATASET_PATH, 'val', val_ids,
                               transform=transforms.Compose([
                                   transforms.Resize(opts.imResize),
                                   transforms.CenterCrop(opts.imsize),
                                   transforms.ToTensor(),
                                   transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),])),
                               batch_size=opts.batchsize, shuffle=False, num_workers=4, pin_memory=True, drop_last=False)
        print('validation_loader done')
        
        # Pretask

        # model = torch.nn.DataParallel(model) 
        # model.to(device)
        # bind_nsml(model)
        # Set optimizer
        # optimizer = optim.Adam(model.parameters(), lr=0.002)
        # # optimizer = optim.RMSprop(model.parameters())

        # # INSTANTIATE LOSS CLASS
        # unlabel_criterion = nt_xent

        # # INSTANTIATE STEP LEARNING SCHEDULER CLASS
        # scheduler = torch.optim.lr_scheduler.MultiStepLR(optimizer,  milestones=[50, 150], gamma=0.1)

        
        # # Train and Validation 
        # # if opts.start_epoch_pretask > 1:
        # #     nsml.load(checkpoint = os.path.join('runs', opts.name + '_pre_e{}'.format(opts.start_epoch_pretask - 1)), session='kaist007/fashion_dataset/130')

        # model.train()
        # print('starting pretask')
        # for epoch in range(1, 201):
        #     # c, s = 0, 0
        #     # pBar = tqdm(unlabel_loader)
        #     # for data in pBar:
        #     for it, data in enumerate(unlabel_loader):
        #         d = data.size()
        #         x = data.view(d[0]*2, d[2], d[3], d[4]).to(device)
        #         optimizer.zero_grad()
        #         p = model(x)
        #         loss = unlabel_criterion(p)
        #         # s = ((s*c)+(float(loss)*len(p)))/(c+len(p))
        #         # c += len(p)
        #         # pBar.set_description('Train: '+str(round(float(s),3)))
        #         loss.backward()
        #         optimizer.step()
        #     scheduler.step()
        #     print("epoch: ", epoch,  "loss: ", loss.item())
        #     if (epoch) % 10 == 0:
        #         if IS_ON_NSML:
        #             nsml.save(opts.name + '_pre_e{}'.format(epoch))
        #         else:
        #             torch.save(model.state_dict(), os.path.join('runs', opts.name + '_pre_e{}'.format(epoch))) 


        # Lp-DeepSSL
        best_prec1 = 0
        global_step = 0
        args = load_args(args, isMT = args.isMT)

        bind_nsml(model)
        nsml.load(checkpoint="resAnetFine002_best5", session="kaist007/fashion_dataset/17063")    #load checkpoint
        model = torch.nn.DataParallel(model)
        bind_nsml(model)
        model.to(device)
        model.eval()

        train_loader, train_loader_noshuff, train_data = create_data_loaders(transforms.Compose([
                                  transforms.Resize(opts.imResize),
                                  transforms.RandomResizedCrop(opts.imsize),
                                  # transforms.Resize((opts.imsize, opts.imsize)),
                                  transforms.RandomHorizontalFlip(),
                                  # transforms.ColorJitter(0.5, 0.5, 0.5, 0.5),
                                  transforms.ToTensor(),
                                  transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),]), 
                                  DATA_PATH,
                                  train_ids + unl_ids,
                                  NUM_CLASSES,
                                  args=args)

        # Starting Accuracy
        prec1, prec5 = validation(opts, validation_loader, model, epoch, use_gpu)
        print("Starting accuracy- top1: {}, top5: {}".format(prec1, prec5))


        model.train()
        train_criterion = nn.CrossEntropyLoss()
        optimizer = torch.optim.SGD(model.parameters(), args.lr,
                    momentum=args.momentum,
                    weight_decay=args.weight_decay) 
        best_acc = -1

        print('start training')
        label_iter = iter(label_loader)
        unlabel_iter = iter(unlabel_loader)
        for epoch in range(1, 1000):
            # Extract features and update the pseudolabels
            print('Extracting features...')
            feats,labels = extract_features(train_loader_noshuff, model, isMT = False)
            sel_acc = train_data.update_plabels(feats, k = args.dfs_k, max_iter = 20)
            print('selection accuracy: %.2f' % (sel_acc))

            #  Train for one epoch with the new pseudolabels
            if args.isMT:
                train_meter, global_step = train(train_loader, model, optimizer, epoch, global_step, args, ema_model = ema_model)
            else:
                train_meter, global_step = train(train_loader, model, optimizer, epoch, global_step, args)

            acc_top1, acc_top5 = validation(opts, validation_loader, model, epoch, use_gpu)
            is_best = acc_top1 > best_acc
            best_acc = max(acc_top1, best_acc)
            nsml.report(summary=True, step=epoch, accuracy_1=acc_top1, accuracy_5=acc_top5)
            if is_best:
                print('saving best checkpoint...')
                if IS_ON_NSML:
                    nsml.save(opts.name + '_best')
                else:
                    torch.save(model.state_dict(), os.path.join('runs', opts.name + '_best'))
            if (epoch) % 50 == 0:
                if IS_ON_NSML:
                    nsml.save(opts.name + '_e{}'.format(epoch))
                else:
                    torch.save(model.state_dict(), os.path.join('runs', opts.name + '_e{}'.format(epoch)))

        # # Fine Tuning      
        # bind_nsml(model)
        # nsml.load(checkpoint="Res18baseMM_pre_e120", session="kaist007/fashion_dataset/217")    #load checkpoint

        # for param in model.parameters():
        #     param.requires_grad = False
        
        # model.fc = nn.Linear(ch, NUM_CLASSES)
        # model = torch.nn.DataParallel(model)
        # bind_nsml(model)
        # model.to(device)

        # optimizer = optim.Adam(model.parameters(), lr=0.3)
        # scheduler = torch.optim.lr_scheduler.MultiStepLR(optimizer, milestones=[200, 400, 600, 800], gamma=0.1)
        # train_criterion = nn.CrossEntropyLoss()

        # best_acc = -1
        # # supervised fine-tuning
        # model.train()
        # print('start training')
        # label_iter = iter(label_loader)
        # unlabel_iter = iter(unlabel_unsym_loader)
        # for epoch in range(1, 1000):
        #     # c, s = 0, 0
        #     # pBar = tqdm(train_loader)
        #     # for data in pBar:
        #     optimizer.zero_grad()
        #     loss_label = 0
        #     loss_sharp = 0
        #     for _ in range(1):
        #         try:
        #             data = next(label_iter)
        #         except:
        #             label_iter = iter(label_loader)
        #             data = next(label_iter)
        #         x, y = data[0].to(device), data[1].to(device)
        #         p = model(x).div(0.4)
        #         loss_label += train_criterion(p, y)
        #     print("label_loss: {}".format(loss_label))
        #     # s = ((s*c)+(float(loss)*len(p)))/(c+len(p))
        #     # c += len(p)
        #     # pBar.set_description('Train: '+str(round(float(s),3)))
        #     with torch.autograd.set_detect_anomaly(True):
        #         for _ in range(30):
        #             try:
        #                 data = next(unlabel_iter)
        #             except:
        #                 unlabel_iter = iter(unlabel_unsym_loader)
        #                 data = next(unlabel_iter)

        #             d = data.size()
        #             x = data.view(d[0]*2, d[2], d[3], d[4]).to(device)
        #             optimizer.zero_grad()
        #             output = model(x).div(0.4)
        #             p = torch.nn.Softmax(dim=1)(output)
        #             p1 = p[::2]
        #             p1_argmax = torch.argmax(p1, dim=1)
        #             p1_max = torch.max(p1, dim=1).values
        #             ths = 0.6
        #             indice_mask = torch.nonzero(p1_max < ths, as_tuple=True)
        #             # p1[indice_mask] = 0
        #             # p1_argmax[indice_mask] = -100
        #             # p1_argmax = p1_argmax.d
        #             # p1 = p1.detach()
        #             p1_argmax[indice_mask] = -100  
        #             p2 = output[1::2]                 
        #             loss_sharp += nn.CrossEntropyLoss()(p2, p1_argmax)
        #             # loss_sharp -= torch.mean(torch.sum(torch.log(p2.pow(p1)), 1)).item()
        #         loss_sharp /= 30
        #         print("loss_sharp: {}".format(loss_sharp))
        #         loss = loss_label + 20 * loss_sharp
        #         loss.backward()

        #     optimizer.step()
        #     scheduler.step()
        #     # if (epoch % 12) == 0:
        #         # scheduler.step() 
        #     # print("epoch: ", epoch,  "loss: ", loss.item())
        #     acc_top1, acc_top5 = validation(opts, validation_loader, model, epoch, use_gpu)
        #     is_best = acc_top1 > best_acc
        #     best_acc = max(acc_top1, best_acc)
        #     nsml.report(summary=True, step=epoch, accuracy_1=acc_top1, accuracy_5=acc_top5)
        #     if is_best:
        #         print('saving best checkpoint...')
        #         if IS_ON_NSML:
        #             nsml.save(opts.name + '_best')
        #         else:
        #             torch.save(model.state_dict(), os.path.join('runs', opts.name + '_best'))
        #     if (epoch) % 50 == 0:
        #         if IS_ON_NSML:
        #             nsml.save(opts.name + '_e{}'.format(epoch))
        #         else:
        #             torch.save(model.state_dict(), os.path.join('runs', opts.name + '_e{}'.format(epoch)))
            

                
# def train(opts, train_loader, unlabel_loader, model, criterion, optimizer, epoch, use_gpu):
#     losses = AverageMeter()
#     losses_x = AverageMeter()
#     losses_un = AverageMeter()
#     weight_scale = AverageMeter()
#     acc_top1 = AverageMeter()
#     acc_top5 = AverageMeter()
#     avg_loss = 0.0
#     avg_top1 = 0.0
#     avg_top5 = 0.0
    
#     model.train()
    
#     nCnt =0 
#     labeled_train_iter = iter(train_loader)
#     unlabeled_train_iter = iter(unlabel_loader)
    
#     for batch_idx in range(len(train_loader)):
#         try:
#             print("label success")
#             data = labeled_train_iter.next()
#             inputs_x, targets_x = data
#         except:
#        	    print("label fail")
#             labeled_train_iter = iter(train_loader)
#             data = labeled_train_iter.next()
#             inputs_x, targets_x = data
#         try:
#             print("unlabel success")
#             data = unlabeled_train_iter.next()
#             inputs_u1, inputs_u2 = data
#         except:
#             print("unlabel fail")
#             unlabeled_train_iter = iter(unlabel_loader)
#             data = unlabeled_train_iter.next()
#             inputs_u1, inputs_u2 = data         
    
#         batch_size = inputs_x.size(0)
#         # Transform label to one-hot
#         classno = NUM_CLASSES 
#         targets_org = targets_x
#         targets_x = torch.zeros(batch_size, classno).scatter_(1, targets_x.view(-1,1), 1)        
        
#         if use_gpu :
#             inputs_x, targets_x = inputs_x.cuda(), targets_x.cuda()
#             inputs_u1, inputs_u2 = inputs_u1.cuda(), inputs_u2.cuda()    
#         inputs_x, targets_x = Variable(inputs_x), Variable(targets_x)
#         inputs_u1, inputs_u2 = Variable(inputs_u1), Variable(inputs_u2)
        
#         with torch.no_grad():
#             # compute guessed labels of unlabel samples
#             embed_u1, pred_u1 = model(inputs_u1)
#             embed_u2, pred_u2 = model(inputs_u2)
#             pred_u_all = (torch.softmax(pred_u1, dim=1) + torch.softmax(pred_u2, dim=1)) / 2
#             pt = pred_u_all**(1/opts.T)
#             targets_u = pt / pt.sum(dim=1, keepdim=True)
#             targets_u = targets_u.detach()
            
#         # mixup
#         all_inputs = torch.cat([inputs_x, inputs_u1, inputs_u2], dim=0)
#         all_targets = torch.cat([targets_x, targets_u, targets_u], dim=0)            
        
#         lamda = np.random.beta(opts.alpha, opts.alpha)        
#         lamda= max(lamda, 1-lamda)    
#         newidx = torch.randperm(all_inputs.size(0))
#         input_a, input_b = all_inputs, all_inputs[newidx]
#         target_a, target_b = all_targets, all_targets[newidx]        
        
#         mixed_input = lamda * input_a + (1 - lamda) * input_b
#         mixed_target = lamda * target_a + (1 - lamda) * target_b
        
#         # interleave labeled and unlabed samples between batches to get correct batchnorm calculation 
#         mixed_input = list(torch.split(mixed_input, batch_size))
#         mixed_input = interleave(mixed_input, batch_size)

#         optimizer.zero_grad()
        
#         fea, logits_temp = model(mixed_input[0])
#         logits = [logits_temp]
#         for newinput in mixed_input[1:]:
#             print(torch.cuda.memory_allocated()/1024**2)
#             fea, logits_temp = model(newinput)
#             logits.append(logits_temp)
#             torch.cuda.empty_cache()

            
#         # put interleaved samples back
#         logits = interleave(logits, batch_size)
#         logits_x = logits[0]
#         logits_u = torch.cat(logits[1:], dim=0)            
        
#         loss_x, loss_un, weigts_mixing = criterion(logits_x, mixed_target[:batch_size], logits_u, mixed_target[batch_size:], epoch+batch_idx/len(train_loader), opts.epochs)
#         loss = loss_x + weigts_mixing * loss_un

#         losses.update(loss.item(), inputs_x.size(0))
#         losses_x.update(loss_x.item(), inputs_x.size(0))
#         losses_un.update(loss_un.item(), inputs_x.size(0))
#         weight_scale.update(weigts_mixing, inputs_x.size(0))
                
#         # compute gradient and do SGD step
#         loss.backward()
#         optimizer.step()
        
#         with torch.no_grad():
#             # compute guessed labels of unlabel samples
#             embed_x, pred_x1 = model(inputs_x)

#         acc_top1b = top_n_accuracy_score(targets_org.data.cpu().numpy(), pred_x1.data.cpu().numpy(), n=1)*100
#         acc_top5b = top_n_accuracy_score(targets_org.data.cpu().numpy(), pred_x1.data.cpu().numpy(), n=5)*100    
#         acc_top1.update(torch.as_tensor(acc_top1b), inputs_x.size(0))        
#         acc_top5.update(torch.as_tensor(acc_top5b), inputs_x.size(0))   
        
#         avg_loss += loss.item()
#         avg_top1 += acc_top1b
#         avg_top5 += acc_top5b  
        
#         if batch_idx % opts.log_interval == 0:
#             print('Train Epoch:{} [{}/{}] Loss:{:.4f}({:.4f}) Top-1:{:.2f}%({:.2f}%) Top-5:{:.2f}%({:.2f}%) '.format( 
#                 epoch, batch_idx *inputs_x.size(0), len(train_loader.dataset), losses.val, losses.avg, acc_top1.val, acc_top1.avg, acc_top5.val, acc_top5.avg))
        
#         nCnt += 1 

#     avg_loss =  float(avg_loss/nCnt)
#     avg_top1 = float(avg_top1/nCnt)
#     avg_top5 = float(avg_top5/nCnt)
    
#     return  avg_loss, avg_top1, avg_top5    


def validation(opts, validation_loader, model, epoch, use_gpu):
    model.eval()
    avg_top1= 0.0
    avg_top5 = 0.0
    nCnt =0 
    with torch.no_grad():
        for batch_idx, data in enumerate(validation_loader):
            inputs, labels = data
            if use_gpu :
                inputs = inputs.cuda()
            inputs = Variable(inputs)
            nCnt +=1
            preds = model(inputs)

            acc_top1 = top_n_accuracy_score(labels.numpy(), preds.data.cpu().numpy(), n=1)*100
            acc_top5 = top_n_accuracy_score(labels.numpy(), preds.data.cpu().numpy(), n=5)*100
            avg_top1 += acc_top1
            avg_top5 += acc_top5

        avg_top1 = float(avg_top1/nCnt)   
        avg_top5= float(avg_top5/nCnt)   
        print('Test Epoch:{} Top1_acc_val:{:.2f}% Top5_acc_val:{:.2f}% '.format(epoch, avg_top1, avg_top5))
    return avg_top1, avg_top5



if __name__ == '__main__':
    main()

