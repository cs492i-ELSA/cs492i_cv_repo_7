import numpy as np
from tqdm import tqdm_notebook as tqdm
from PIL import Image

import torch
import torch.nn as nn
from torch.optim import Adam
from torch.utils.data import DataLoader, Dataset
import torchvision.transforms as tfs
from torchvision.datasets import *
from torchvision.models import *
from torchvision import datasets, models, transforms
from ImageDataLoader import SimpleImageLoader
import os
import main
import argparse
import torch

DATASET_PATH = 'fashion_demo'

parser = argparse.ArgumentParser(description='SimCLR Product200K Training')
parser.add_argument('--imsize', default=224, type=int, help='')
parser.add_argument('--imResize', default=256, type=int, help='')
parser.add_argument('--batchsize', default=200, type=int, help='batchsize')
opts = parser.parse_args()



device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

tf_tr = tfs.Compose([
    tfs.RandomResizedCrop(32),
    tfs.RandomHorizontalFlip(),
    tfs.ColorJitter(0.5, 0.5, 0.5, 0.5),
    tfs.ToTensor(),
    tfs.Normalize(mean=[0.485, 0.456, 0.406], 
                  std=[0.229, 0.224, 0.225])
])

tf_de = tfs.Compose([
    tfs.Resize(32),
    tfs.ToTensor(),
    tfs.Normalize(mean=[0.485, 0.456, 0.406], 
                  std=[0.229, 0.224, 0.225])
])

tf_te = tfs.Compose([
    tfs.Resize(32),
    tfs.ToTensor(),
    tfs.Normalize(mean=[0.485, 0.456, 0.406], 
                  std=[0.229, 0.224, 0.225])
])

# class CustomCIFAR10(CIFAR10):
#     def __init__(self, **kwds):
#         super().__init__(**kwds)
            
#     def __getitem__(self, idx):
#         if not self.train:
#             return super().__getitem__(idx)
    
#         img = self.data[idx]
#         img = Image.fromarray(img).convert('RGB')
#         imgs = [self.transform(img), self.transform(img)]
#         return torch.stack(imgs)

train_ids, val_ids, unl_ids = main.split_ids(os.path.join(DATASET_PATH, 'train/train_label'), 0.2)

dl_tr = DataLoader(
            SimpleImageLoader(DATASET_PATH, 'unlabel', unl_ids,
                              transform=transforms.Compose([
                                  transforms.Resize(opts.imResize),
                                  transforms.RandomResizedCrop(opts.imsize),
                                  transforms.RandomHorizontalFlip(),
                                  transforms.RandomVerticalFlip(),
                                  transforms.ToTensor(),
                                  transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),])),
                                batch_size=opts.batchsize, shuffle=True, num_workers=4, pin_memory=True, drop_last=True)

ds_de = SimpleImageLoader(DATASET_PATH, 'train', train_ids,
                              transform=transforms.Compose([
                                  transforms.Resize(opts.imResize),
                                  transforms.RandomResizedCrop(opts.imsize),
                                  transforms.RandomHorizontalFlip(),
                                  transforms.RandomVerticalFlip(),
                                  transforms.ToTensor(),
                                  transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),]))
dl_de = torch.utils.data.DataLoader(ds_de, batch_size=opts.batchsize, shuffle=True, num_workers=4, pin_memory=True, drop_last=True)

# ds_tr = CustomCIFAR10(root='data', train=True, transform=tf_tr, download=True)
# ds_de = CIFAR10(root='data', train=True, transform=tf_de, download=True)
# ds_te = CIFAR10(root='data', train=False, transform=tf_te, download=True)

# dl_tr = DataLoader(ds_tr, batch_size=256, shuffle=True)
# dl_de = DataLoader(ds_de, batch_size=256, shuffle=True)
# dl_te = DataLoader(ds_te, batch_size=256, shuffle=False)

model = resnet50(pretrained=False)
model.conv1 = nn.Conv2d(3, 64, 3, 1, 1, bias=False)
model.maxpool = nn.Identity()

ch = model.fc.in_features
model.fc = nn.Sequential(nn.Linear(ch, ch),
                           nn.ReLU(),
                           nn.Linear(ch, ch))
model.to(device)
model.train()

def pair_cosine_similarity(x, eps=1e-8):
    n = x.norm(p=2, dim=1, keepdim=True)
    return (x @ x.t()) / (n * n.t()).clamp(min=eps)

def nt_xent(x, t=0.5):
    x = pair_cosine_similarity(x)
    x = torch.exp(x / t)
    idx = torch.arange(x.size()[0])
    idx[::2] += 1
    idx[1::2] -= 1
    x = x[idx]
    x = x.diag() / (x.sum(0) - torch.exp(torch.tensor(1 / t)))
    return -torch.log(x.mean())

optimizer = Adam(model.parameters(), lr=0.001)

# unsupervised
model.train()
for i in range(1):
    c, s = 0, 0
    pBar = tqdm(dl_tr)
    for data in pBar:
        d = data.size()
        x = data.view(d[0]*2, d[2], d[3], d[4]).to(device)
        optimizer.zero_grad()
        p = model(x)
        loss = nt_xent(p)
        s = ((s*c)+(float(loss)*len(p)))/(c+len(p))
        c += len(p)
        pBar.set_description('Train: '+str(round(float(s),3)))
        loss.backward()
        optimizer.step()
    if (i+1) % 10 == 0:
        torch.save(model.state_dict(), 'rn50-mlp-b256-t0.5-e'+str(i+1)+'.pt')

# before adding linear classifier for supervised learning (fine-tuning)
for param in model.parameters():
    param.requires_grad = False

model.fc = nn.Linear(ch, len(ds_de.imclasses))
model.to(device)

optimizer = Adam(model.parameters(), lr=0.003)
criterion = nn.CrossEntropyLoss()

# supervised fine-tuning
model.train()
for i in range(5):
    c, s = 0, 0
    pBar = tqdm(dl_de)
    for data in pBar:
        x, y = data[0].to(device), data[1].to(device)
        optimizer.zero_grad()
        p = model(x)
        loss = criterion(p, y)
        s = ((s*c)+(float(loss)*len(p)))/(c+len(p))
        c += len(p)
        pBar.set_description('Train: '+str(round(float(s),3)))
        loss.backward()
        optimizer.step()

# another supervised fine-tuning
optimizer = Adam(model.parameters(), lr=0.0001)
criterion = nn.CrossEntropyLoss()

model.train()
for i in range(5):
    c, s = 0, 0
    pBar = tqdm(dl_de)
    for data in pBar:
        x, y = data[0].to(device), data[1].to(device)
        optimizer.zero_grad()
        p = model(x)
        loss = criterion(p, y)
        s = ((s*c)+(float(loss)*len(p)))/(c+len(p))
        c += len(p)
        pBar.set_description('Train: '+str(round(float(s),3)))
        loss.backward()
        optimizer.step()